import numpy as np
import pandas as pd
from tqdm import tqdm
from submission import your_prompt, your_config, your_api_key, your_post_processing, your_pre_processing
from together import Together
from time import sleep
import ast
import inspect
from sklearn.metrics import mean_absolute_error

API_KEY = your_api_key()
client = Together(api_key=API_KEY)

def contains_addition(node):
    """Recursively check if the given AST node or its children contain an addition operation."""
    if isinstance(node, ast.Add):
        return True
    for child in ast.iter_child_nodes(node):
        if contains_addition(child):
            return True
    return False

def function_uses_addition(func):
    """Check if a function uses arithmetic addition."""
    source = inspect.getsource(func)  # Get the source code of the function
    tree = ast.parse(source)
    return contains_addition(tree)

def get_addition_pairs(lower_bound, upper_bound, rng):
    int_a = int(np.ceil(rng.uniform(lower_bound, upper_bound)))
    int_b = int(np.ceil(rng.uniform(lower_bound, upper_bound)))
    int_c = int(np.ceil(rng.uniform(lower_bound, upper_bound)))
    return int_a, int_b, int_c

def call_together_api(prompt, student_configs, post_processing):
    output = client.completions.create(
    prompt = prompt,
    model = "meta-llama/Llama-2-13b-chat-hf", 
    **student_configs
    )
    res = output.choices[0].text
    numbers_only = post_processing(res)
    return numbers_only

def test_range(added_prompt, prompt_configs, rng, n_sample=30, lower_bound=1, upper_bound=10, fixed_pairs=None, 
               pre_processing=your_pre_processing,post_processing=your_post_processing):
    int_as = []
    int_bs = []
    int_cs = []
    answers = []
    model_responses = []
    correct = []
    prompts = []
    iterations = fixed_pairs if not (fixed_pairs is None) else []
    for _ in range(n_sample):
        int_a, int_b, int_c = get_addition_pairs(lower_bound, upper_bound, rng=rng)
        iterations.append((int_a, int_b, int_c))
    
    for i, v in enumerate(tqdm(iterations)):
        int_a, int_b, int_c = v
        fixed_prompt = f"{int_a}+{int_b}+{int_c}"
        fixed_prompt = pre_processing(fixed_prompt)
        prefix, suffix = added_prompt
        prompt = prefix + fixed_prompt + suffix
        response = call_together_api(prompt, prompt_configs, post_processing)
        answer = int_a + int_b + int_c
        int_as.append(int_a)
        int_bs.append(int_b)
        int_cs.append(int_c)
        answers.append(answer)
        model_responses.append(response)
        correct.append(answer == response)
        prompts.append(prompt)
        sleep(1)

    df = pd.DataFrame({
        'prompt': prompts,
        'int_a': int_as,
        'int_b': int_bs,
        'int_c': int_cs,
        'answer': answers,
        'model_response': model_responses,
        'correct': correct
    })

    mae = mean_absolute_error(df['answer'], df['model_response'])
    acc = df['correct'].sum() / len(df)
    prompt_length = len(prefix) + len(suffix)
    res = acc * (1 / prompt_length) * (1 - mae / (1 * (10**4)))
    return {
        'res': res,
        'acc': acc,
        'mae': mae,
        'prompt_length': prompt_length
    }


if __name__ == '__main__':
    student_config = your_config()
    # check that students did not modify keys, e.g., using more powerful model to achive better result
    fixed_keys = ['max_tokens', 'temperature', 'top_k', 'top_p', 'repetition_penalty', 'stop']
    assert(student_config['max_tokens'] >= 50)
    for key, item in student_config.items():
        if not key in fixed_keys:
            raise ValueError(f'please do not add additional key {key}')
    if not (len(fixed_keys) == len(student_config)):
            raise ValueError(f'expected to see a config dict of size {len(fixed_keys)}, but found {len(student_config)}')
    # check that postprocessing did not contain hack
    if function_uses_addition(your_post_processing):
        raise ValueError('please do not use addition in your post processing function')

    # 30 pairs in total
    accs = []
    maes = []
    for trial in range(3): # do 3 trials because same data same prompt could yield different result
        seed=0
        rng = np.random.default_rng(seed)
        res_large = test_range(your_prompt(), student_config, rng, n_sample=29, lower_bound=10000, upper_bound=99999,
                               fixed_pairs=[(54321, 76543, 98765)],
                               post_processing=your_post_processing, pre_processing=your_pre_processing)
        print(res_large)
        sleep(1)
        accs.append(res_large['acc'])
        maes.append(res_large['mae'])
    plen = res_large['prompt_length']
    print(f"Averaged accuracy: {np.mean(accs)}, averaged MAE: {np.mean(maes)}, prompt length: {plen}")